#include<bits/stdc++.h>
using namespace std;
map<char, string>mp;
map<string, char>mp1;
string str;
main() {
	mp['0'] = "0000";
	mp['1'] = "0001";
	mp['2'] = "0010";
	mp['3'] = "0011";
	mp['4'] = "0100";
	mp['5'] = "0101";
	mp['6'] = "0110";
	mp['7'] = "0111";
	mp['8'] = "1000";
	mp['9'] = "1001";
	mp['A'] = "1010";
	mp['B'] = "1011";
	mp['C'] = "1100";
	mp['D'] = "1101";
	mp['E'] = "1110";
	mp['F'] = "1111";

	mp1["000"] = '0';
	mp1["001"] = '1';
	mp1["010"] = '2';
	mp1["011"] = '3';
	mp1["100"] = '4';
	mp1["101"] = '5';
	mp1["110"] = '6';
	mp1["111"] = '7';
	cin >> str;
	string s, t;
	for (int i = 0; i < str.length(); i++) ///��ʮ�����Ƶ��ַ���ת��Ϊ������
		t = t + mp[str[i]];
	if (t.size() % 3 == 1) t = "00" + t;
	else if (t.size() % 3 == 2) t = "0" + t; ///����ǰ׺0
	for (int i = 0; i < t.size(); i += 3) ///��������ת��Ϊ�˽���
		s = s + mp1[t.substr(i, 3)];
	bool flag = 0;
	for (int i = 0; i < s.size(); i++) {
		if (s[i] == '0' && flag == 0) continue; ///ȥ��ǰ׺0
		flag = 1;
		printf("%c", s[i]);
	}
	printf("\n");
}
