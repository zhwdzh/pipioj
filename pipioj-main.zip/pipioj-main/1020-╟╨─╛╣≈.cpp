#include<iostream>
#include<bits/stdc++.h>

using namespace std;

int main() {
	int n;
	while (scanf("%d", &n) != EOF) { //��cin��cout�ᳬʱ
		int count = 0;
		if (n % 2 == 1 || n < 6) {
			printf("%d\n", count);
			continue;
		}
		count = n / 2 - n / 4 - 1;
		printf("%d\n", count);
	}
	return 0;

}
