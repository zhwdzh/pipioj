#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cmath>
#include<queue>
#include<cstring>
#include<vector>
#include<stack>
#include<map>
#include<set>
#define MAX 5005
#define INF 0x3f3f3f3f
typedef long long ll;
using namespace std;

string s;
int dp[MAX][MAX];

int main() {
	while (cin >> s) {
		memset(dp, 0, sizeof(dp));
		int len = s.length(), ans = 0;

		for(int i=len-1;i>=0;i--){
		    for(int j=i;j<len;j++){
		        if(s[i]==s[j]){
		            if(dp[i+1][j-1]==1||j-i<3){
		                dp[i][j]=1;
		                ans++;
		            }
		        }
		    }
		}
		printf("%d\n", ans);
	}
	return 0;
}
