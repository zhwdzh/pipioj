#include<iostream>
#include<bits/stdc++.h>

using namespace std;

int main() {
	int num[10] = {0};

	string a;
	while (cin >> a) {
		memset(num, 0, sizeof(num));
		int len = a.size();
		for (int i = 0; i < len; i++) {
			if (a[i] == '0') {
				++num[0];
			} else if (a[i] == '1') {
				++num[1];
			} else if (a[i] == '2') {
				++num[2];
			} else if (a[i] == '3') {
				++num[3];
			} else if (a[i] == '4') {
				++num[4];
			} else if (a[i] == '5') {
				++num[5];
			} else if (a[i] == '6') {
				++num[6];
			} else if (a[i] == '7') {
				++num[7];
			} else if (a[i] == '8') {
				++num[8];
			} else if (a[i] == '9') {
				++num[9];
			}
		}

		//��������
		int max_num = 0, n = 0;
		for (int i = 0; i < 10; i++) {
			if (max_num < num[i]) {
				max_num = num[i];
				n = i;
			}
		}
		cout << n << endl;
	}
	return 0;

}
