#include<iostream>
#include<cstring>
using namespace std;

string s;

char a[26][26];

int main() {
	while (cin >> s) {
		bool flag = true;

		for (int i = 0; i < 25; i++) {
			a[i][0] = s[i];
			int pos = 1;
			for (int j = i + 1; j < 26; j++) {
				if (s[j] < s[i]) {  //�����ջ���ֲ����ǽ����
					a[i][pos++] = s[j];
					if (a[i][pos - 1] > a[i][pos - 2]) flag = false;  
				}
			}
		}
		
		if (flag) cout << "yes" << endl;
		else cout << "no" << endl;
	}
}
