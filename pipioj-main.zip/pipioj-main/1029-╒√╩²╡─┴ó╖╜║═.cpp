#include<iostream> 
#include<vector> 
using namespace std;
void sumM(int n){
	long long sum=0;
	for(int i=1;i<=n;i++){
		sum+=i*i*i;
	}
	cout<<sum<<endl;
}
int main()
{
	vector<int> f; 
    int n;
    while(scanf("%d", &n)!=EOF)
    {
        f.push_back(n); 
	}
	
	for(int i=0;i<f.size();i++){
		sumM(f[i]);
	}
    
    
    return 0;
}

