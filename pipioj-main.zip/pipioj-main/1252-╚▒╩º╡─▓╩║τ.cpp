#include<iostream>
#include<bits/stdc++.h>
#define MAX 105
#define INF 0x3f3f3f3f
typedef long long ll;
using namespace std;

map<string, int> color;
int n, flag[8];
string s[MAX];

int main() {
	color["red"] = 0;
	color["orange"] = 1;
	color["yellow"] = 2;
	color["green"] = 3;
	color["cyan"] = 4;
	color["blue"] = 5;
	color["purple"] = 6;

	while (cin >> n) {
		memset(flag, 0, sizeof(flag));
		for (int i = 0; i < n; i++) {
			cin >> s[i];
			flag[color[s[i]]] = 1;
		}
        int cnt=0;
        for(int i=0;i<7;i++){
            if(flag[i]==0) cnt++;
        }
		cout << cnt << endl;
		for (int i = 0; i < 7; i++) {
			if (flag[i] == 0) {
				if (i == 0) cout << "A" << endl;
				else if (i == 1) cout << "B" << endl;
				else if (i == 2) cout << "C" << endl;
				else if (i == 3) cout << "D" << endl;
				else if (i == 4) cout << "E" << endl;
				else if (i == 5) cout << "F" << endl;
				else if (i == 6) cout << "G" << endl;
			}
		}
	}

	return 0;

}
