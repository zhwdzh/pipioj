#include<iostream>
#include<bits/stdc++.h>

using namespace std;

int main() {
	int t, id = 1;
	scanf("%d", &t);
	double x1, x2, y1, y2, vx1, vy1, vx2, vy2;
	while (t--) {
		scanf("%lf%lf%lf%lf", &x1, &y1, &x2, &y2);
		scanf("%lf%lf%lf%lf", &vx1, &vy1, &vx2, &vy2);

		double A, B, C, D, xmid, ans;
		A = x1 - x2, B = vx1 - vx2, C = y1 - y2, D = vy1 - vy2;
		xmid = -(A * B + C * D) / (B * B + D * D);			///xmid��ʾʱ�䣬��xmidʱ�������
		if (xmid <= 0 || (B == 0 && D == 0)) ans = A * A + C * C;
		else {
			x1 += vx1 * xmid, y1 += vy1 * xmid;				///С�����е�λ��
			x2 += vx2 * xmid, y2 += vy2 * xmid;				///С�����е�λ��
			ans = (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2); ///��ͳ���빫ʽ
		}
		printf("Case %d: %.6f\n", id++, sqrt(ans));
	}
	return 0;
}
