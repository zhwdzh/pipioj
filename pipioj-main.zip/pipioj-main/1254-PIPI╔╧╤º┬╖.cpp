#include<iostream>
#include<bits/stdc++.h>
#define MAX 5005
#define INF 0x3f3f3f3f
typedef long long ll;
using namespace std;

int n, m, q;
int dp[MAX][MAX];
int mod = 1e9 + 7;
int x1, y_1, x2, y2;


int main() {

	//��dp����  ״̬ת�Ʒ��̣�dp[i][j]��ʾ�� (0,0)��(i,j)��·����Ŀ
	//dp[i][j] = dp[i-1][j] + dp[i][j-1]
	while ( cin >> n >> m >> q ) {
		memset(dp, 0, sizeof(dp));
		for (int i = 1; i <= n; i++) dp[i][1] = 1;  //ע��߽��ʼֵ
		for (int j = 1; j <= m; j++) dp[1][j] = 1;
		for (int i = 2; i <= n; i++) {
			for (int j = 2; j <= m; j++) {
				dp[i][j] = (dp[i - 1][j] + dp[i][j - 1]) % mod;
			}
		}

		for (int i = 0; i < q; i++) {
			scanf("%d %d %d %d", &x1, &y_1, &x2, &y2);
			x2 = x2 - x1 + 1, y2 = y2 - y_1 + 1;   //ƽ��һ��
			printf("%d\n", dp[x2][y2]);
		}

	}

	return 0;

}
