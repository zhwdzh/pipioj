#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cmath>
#include<queue>
#include<cstring>
#include<vector>
#include<stack>
#include<map>
#include<set>
#define MAX 1000005
#define INF 0x3f3f3f3f
typedef long long ll;
using namespace std;

int n, c, a[MAX];
ll dp[MAX];

int main() {
	ll sum = 0;
	multiset<int> s; //���ؼ�
	scanf("%d %d", &n, &c);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
		sum += a[i];
	}
	for (int i = 1; i <= n; i++) {
		dp[i] = dp[i - 1];
		s.insert(a[i]);
		if (i > c) s.erase(s.find(a[i - c]));
		if (i >= c) dp[i] = max(dp[i], dp[i - c] + (*s.begin()));
	}
	printf("%lld", sum - dp[n]);
	return 0;
}
