#include<bits/stdc++.h>
using namespace std;
char a[810][810];
int vis[810][810];
int dir[4][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
int ans[810][810];

typedef struct Node {
	int x, y, t;
} node;

int main() {
	int n, m, len;
	while (scanf("%d%d", &n, &m) != EOF) {
		memset(vis, 0, sizeof(vis));
		memset(ans, 0, sizeof(ans));
		queue<node> q;
		for (int i = 0; i < n; i++) {
			scanf("%s", a[i]);
			for (int j = 0; j < m; j++)
				if (a[i][j] == '0') {
					q.push({i, j, 0});
					vis[i][j] = 1;
				}
		}
		node p;
		while (!q.empty()) {
			len = q.size();
			while (len--) {
				p = q.front();
				q.pop();
				for (int i = 0; i < 4; i++) {
					int x = p.x + dir[i][0], y = p.y + dir[i][1];
					if (x >= 0 && x < n && y >= 0 && y < m && !vis[x][y]) {
						q.push({x, y, p.t + 1});
						ans[x][y] = p.t + 1;
						vis[x][y] = 1;
					}
				}
			}
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++)
				printf("%d ", ans[i][j]);
			printf("\n");
		}
	}
	return 0;
}
