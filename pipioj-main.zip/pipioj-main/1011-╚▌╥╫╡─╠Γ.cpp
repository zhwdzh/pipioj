#include<iostream>
#include<bits/stdc++.h>

using namespace std;

int main() {
	char s[1010];
	char min[] = "EASY";
	while (gets(s) != NULL) {
		int len = strlen(s);
		int a = 0;
		int i;
		for (i = 0; i < len; i++) {
			if (s[i] == min[a]) {
				a++;
				if (a == 4)
					break;
			}
		}

		if (a == 4)
			printf("easy\n");
		else
			printf("difficult\n");

	}
}
