#include <bits/stdc++.h>
using namespace std;

const int N = 110;
char maze[N][N];
int n, m;
int sx, sy, tx, ty, k;                                      ///cnt��¼�������
int vis[N][N];
int dir[][2] = {{0, 1},
	{0, -1},
	{1, 0},
	{-1, 0}
};

struct node {
	int x, y, cnt;                      ///cnt ��ʾ����(x,y)�����յ����ٴ�������
};

bool check(int x, int y) {
	if (x < 0 || x >= n || y < 0 || y >= m || maze[x][y] == '*') return false;
	return true;
}

bool bfs() {
	queue<node> q;
	memset(vis, 0, sizeof (vis));
	vis[sx][sy] = 1;
	q.push({sx, sy, -1});

	while (!q.empty()) {
		int x = q.front().x, y = q.front().y, cnt = q.front().cnt;
		q.pop();

		if (cnt > k) return false;
		if (x == tx && y == ty) return true;

		for (int i = 0; i < 4; i++) {
			int nx = x + dir[i][0], ny = y + dir[i][1], ncnt = cnt + 1;

			while (check(nx, ny)) {         ///�����һ��λ�ò����ϰ�����û�����߽��һֱ����ȥ
				if (vis[nx][ny] == 0) {
					vis[nx][ny] = 1;
					q.push({nx, ny, ncnt});
				}
				nx = nx + dir[i][0];
				ny = ny + dir[i][1];
			}

		}
	}
	return false;
}

int main() {
	int t;
	scanf("%d", &t);

	while (t--) {
		scanf("%d%d", &n, &m);
		for (int i = 0; i < n; i++) scanf("%s", maze[i]);

		scanf("%d%d%d%d%d", &k, &sy, &sx, &ty, &tx);
		sy--, sx--, ty--, tx--;
		if (maze[sx][sy] == '*' || maze[tx][ty] == '*') {
			puts("no");
			continue;
		}

		if (bfs()) puts("yes");
		else puts("no");
	}

	return 0;
}
