#include<iostream>
#include<bits/stdc++.h>
#define MAX 105
#define INF 0x3f3f3f3f
typedef long long ll;
using namespace std;

int main() {
	ll a, b, c;

	while ( ~scanf("%lld %lld %lld", &a, &b, &c) ) {

		if ( a + b <= c) {
			printf("YES\n");
			continue;
		}
		if ( c < a) {
			printf("NO\n");
			continue;
		}

		b = b - a * c + 0.5 * a * a + 0.5 * a;

//		int i = 1;
//		while (b > 0) {
//			b = b - c + i;
//			++i;
//			if (i > a || b <= 0) {
//				break;
//			}
//		}

		if (b <= 0) {
			printf("YES\n");
		} else if (b > 0 && c - a >= b) {
			printf("YES\n");
		} else {
			printf("NO\n");
		}

	}

	return 0;

}
