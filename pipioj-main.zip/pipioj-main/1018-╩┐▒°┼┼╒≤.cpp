#include<iostream>
#include<bits/stdc++.h>

#define INF 0x3f3f3f3f
using namespace std;

const int maxn = 1e4 + 5;

int n, x[maxn], y[maxn];


//̰�� ��ѧ

int main() {
	while (~scanf("%d", &n)) {
		for (int i = 1; i <= n; i++) {
			scanf("%d %d", &x[i], &y[i]);
		}

		sort(x + 1, x + 1 + n);

		for (int i = 1; i <= n; i++) {
			x[i] -= i - 1;
		}

		sort(x + 1, x + 1 + n);
		sort(y + 1, y + 1 + n);

		int xmid = x[(n + 1 + 1) / 2]; // x[mid]
		int ymid = y[(n + 1 + 1) / 2]; // y[mid]
		int cnt = 0;

		for (int i = 1; i <= n; i++) {
			cnt += abs(x[i] - xmid) + abs(y[i] - ymid);
		}

		printf("%d\n", cnt);
	}
	return 0;
}
