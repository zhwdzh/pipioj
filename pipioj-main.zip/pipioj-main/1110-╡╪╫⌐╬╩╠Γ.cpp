#include<bits/stdc++.h>
using namespace std;
char a[30][30];
int vis[30][30];
int dir[4][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

typedef struct Node {
	int x, y, t;
} node;

int main() {
	int w, h, ans;
	while (scanf("%d%d", &w, &h) != EOF) {
		if (w == 0 || h == 0) {
			break;
		}

		ans = 0;
		memset(vis, 0, sizeof(vis));
		queue<node> q;
		for (int i = 0; i < h; i++) {
			scanf("%s", a[i]);
			for (int j = 0; j < w; j++)
				if (a[i][j] == '@') {
					q.push({i, j, 0});
					vis[i][j] = 1;
					ans++;
				}
		}

		node p;
		while (!q.empty()) {
			p = q.front();
			q.pop();
			for (int i = 0; i < 4; i++) {
				int x = p.x + dir[i][0], y = p.y + dir[i][1];
				if (x >= 0 && x < h && y >= 0 && y < w && !vis[x][y] && a[x][y] == '.') {
					q.push({x, y, p.t + 1});
					vis[x][y] = 1;
					ans++;
				}
			}
		}

		printf("%d\n", ans);

	}
	return 0;
}
