#include<bits/stdc++.h>

using namespace std;

int n, m;
vector<vector<int>> adjList;
map<int, int> index_m;
map<int, bool> vis;

void dfs(int cur) {
	vis[cur] = true;
	int k = index_m[cur];
	for (int i = 0; i < adjList[k].size(); i++) {
		if (!vis[adjList[k][i]])
			dfs(adjList[k][i]);
	}
}

int main() {
	while (cin >> n >> m) {
		adjList.clear();
		index_m.clear();
		int u;
		for (int i = 0; i < m; i++) {
			scanf("%d", &u);
			adjList.emplace_back(vector<int> {u});
			index_m[u] = i;
			vis[u] = false;
		}
		//create map
		for (int i = 0; i < m - 1; i++) {
			for (int j = i + 1; j < m; j++) {
				if ((adjList[i][0] & adjList[j][0]) == 0) {
					adjList[i].push_back(adjList[j][0]);
					adjList[j].push_back(adjList[i][0]);
				}
			}
		}
		//dfs
		int cnt = 0;
		for (int i = 0; i < m; i++) {
			if (!vis[adjList[i][0]]) {
				dfs(adjList[i][0]);
				cnt++;
			}
		}
		cout << cnt << endl;
	}
	return 0;
}
