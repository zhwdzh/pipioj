#include<iostream>
#include<bits/stdc++.h>

#define MAX 1005
#define INF 0x3f3f3f3f

typedef long long ll;
using namespace std;

int n, m, s, t, limit;
int mp[MAX][MAX], dis[MAX], vis[MAX];

void dijkstra() {
	memset(vis, 0, sizeof(vis));
	memset(dis, INF, sizeof(dis));
	dis[s] = 0;
	for (int i = 0; i < n; i++) {
		int u = -1, minl = INF;
		for (int j = 1; j <= n; j++) {
			if (dis[j] < minl && vis[j] == 0) {
				u = j;
				minl = dis[j];
			}
		}
		if (u == -1) break;
		vis[u] = 1;
		for (int v = 1; v <= n; v++) {
			if (mp[u][v] != INF && vis[v] == 0) {
				if (dis[v] > dis[u] + mp[u][v]) {
					dis[v] = dis[u] + mp[u][v];
				}
			}
		}
	}
}

int main() {
	while (scanf("%d %d %d %d %d", &n, &m, &s, &t, &limit) != EOF) {
		for (int i = 0; i < MAX; i++) {
			for (int j = 0; j < MAX; j++) {
				mp[i][j] = INF;
			}
		}

		int a, b, len;

		for (int i = 0; i < m; i++) {
			scanf("%d %d %d", &a, &b, &len);
			if (a % 2 == 0) mp[a][b] = len + 2;
			else mp[a][b] = len + 1;
			if (b % 2 == 0) mp[b][a] = len + 2;
			else mp[b][a] = len + 1;
		}

		dijkstra();

		if (dis[t] > limit) printf("KENG\n");
		else printf("YES %d\n", dis[t]);
	}
	return 0;
}
