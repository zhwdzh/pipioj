#include<stdio.h>
#define MAX 1000005

typedef long long ll;


int n, dp[MAX];
int mod = 1e9 + 7;

int main() {
	// Ԥ����
	dp[1] = 1, dp[2] = 2;
	for (int i = 3; i < MAX; i++) {
		dp[i] = (dp[i - 1] + dp[i - 2]) % mod;
	}
	// ����
	while (scanf("%d", &n) != EOF) { // ���� cin>>n �ᳬʱ����
		printf("%d\n", dp[n]);
	}
	return 0;
}
