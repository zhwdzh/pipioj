#include<iostream>
#include<bits/stdc++.h>
using namespace std;

struct node {
	int x, y, k, t;
} p;
const int N = 103;
bool vis[N][N][N];
char s[N][N];
int dir[4][2] = {
	{1, 0}, {-1, 0}, {0, 1}, {0, -1}
};
int dx[8] = {1, 1, -1, -1, 2, 2, -2, -2};
int dy[8] = {2, -2, 2, -2, 1, -1, 1, -1};


int main() {
	int m, n, k;
	while ( ~scanf("%d%d%d", &m, &n, &k) ) {
		queue<node>q;
		for (int i = 0; i <= m; ++i) {
			scanf("%s", s[i]);
			for (int j = 0; j < n; ++j) {
				for (int h = 0; h <= k; ++h) {
					vis[i][j][h] = 0;
				}
				if (s[i][j] == 'S') {
					q.push({i, j, k, 0});
					vis[i][j][k] = 1;
				}
			}
		}
		while (!q.empty()) {
			p = q.front();
			q.pop();
			if (s[p.x][p.y] == 'T')break;
			for (int i = 0; i < 4; ++i) { //����
				int nx = p.x + dir[i][0], ny = p.y + dir[i][1];
				if (nx < 0 || nx >= m || ny < 0 || ny >= n || s[nx][ny] == '#' || vis[nx][ny][p.k]){
					continue;
				}
				q.push({nx, ny, p.k, p.t + 1});
				vis[nx][ny][p.k] = 1;
			}
			if (p.k == 0)continue;
			for (int i = 0; i < 8; ++i) { //��Ծ
				int nx = p.x + dx[i], ny = p.y + dy[i];
				if (nx < 0 || nx >= m || ny < 0 || ny >= n || s[nx][ny] == '#' || vis[nx][ny][p.k - 1]){
					continue;
				}
				q.push({nx, ny, p.k - 1, p.t + 1});
				vis[nx][ny][p.k - 1] = 1;
			}
		}
		if (s[p.x][p.y] == 'T'){
			printf("%d\n", p.t);
		}else{
			puts("impossible");//û�ҵ��յ�
		} 
		
	}
	return 0;
}
