#include<iostream>
#include<bits/stdc++.h>
#define MAX 105
#define INF 0x3f3f3f3f
typedef long long ll;
using namespace std;

int main() {
	int i = 0;
	stack<int> stk;
	map<int, int> match;
	string s;
	while (cin >> s) {
		stk.empty();
		for (int i = 0; i < s.size(); i++) {
			if (s[i] == '(') {
				stk.push(i + 1);
			} else if (s[i] == ')' && !stk.empty()) {
				match[stk.top()] = i + 1;
				stk.pop();
			}
		}
		for (auto x : match) {
			printf("%d %d\n", x.first, x.second);
		}

	}
	return 0;
}
