#include <bits/stdc++.h>
using namespace  std;
typedef long long ll;
const ll mod = 1e9 + 7;
const int N = 2e2 + 5;
int T, n, m;
int a[N][N];
int d[N], f[N], e[N];
int main() {
	while (~scanf("%d%d", &n, &m)) {
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				scanf("%d", &a[i][j]);
			}
			d[1] = a[i][1];
			for (int j = 2; j <= m; j++) {
				d[j] = max(d[j - 2] + a[i][j], d[j - 1]);
			}
			f[i] = d[m];
		}

		e[1] = f[1];
		for (int i = 2; i <= n; i++) {
			e[i] = max(e[i - 1], e[i - 2] + f[i]);
		}
		printf("%d\n", e[n]);
	}
}
