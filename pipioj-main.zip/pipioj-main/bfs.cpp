#include<iostream>
#include<bits/stdc++.h>
#define MAX 105
#define INF 0x3f3f3f3f
typedef long long ll;
using namespace std;

const int N = 105;

typedef struct node {
	int x, y, cnt;
} p;

int dir[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
bool vis[10005];
queue<node> q;
int m, n, k, x1, y_1, x2, y2;
char mp[N][N];

bool check(int x, int y) {
	if (x < 0 || x >= n || y < 0 || y >= m || mp[x][y] == '*') return false;
	return true;
}

void BFS() {

}

int main() {
	int t;//�������ݸ���
	for (int k = 0; k < t; k++) {
		cin >> m >> n;
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				cin >> mp[i][j];
			}
		}
		cin >> k >> x1 >> y_1 >> x2 >> y2;


	}
	return 0;
}
