#include<bits/stdc++.h>
using namespace std;
int m, n;
char maps[105][105];
bool visted[105][105];
int dir[][2] = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};

void dfs(int x1, int y1, int x2, int y2, int dir_index, int counts, bool& flag) {
	visted[x1][y1] = true;
	//cout<<x1+1<<" "<<y1+1<<endl;
	if (x1 == x2 && y1 == y2) {
		flag = true;
	}

	if (flag == false) {
		for (int i = 0; i <= 3; i++) {

			int newx = x1 + dir[(dir_index + i) % 4][0];
			int newy = y1 + dir[(dir_index + i) % 4][1];
			if (newx >= 0 && newx <= m - 1 && newy >= 0 && newy <= n - 1 && visted[newx][newy] == false && flag == false && maps[newx][newy] != '*') {
				if (i == 0)
					dfs(newx, newy, x2, y2, (dir_index + i) % 4, counts, flag);
				else if (counts > 0) {
					//cout<<"ת��"<<endl;
					dfs(newx, newy, x2, y2, (dir_index + i) % 4, counts - 1, flag);
				}

			}
		}

	}


}
int main() {
	int t;
	scanf("%d", &t);
	for (int i = 0; i < t; i++) {

		scanf("%d%d", &m, &n);
		for (int j = 0; j < m; j++) {
			scanf("%s", maps[j]);

		}
		/*
		for(int j=0;i<m;j++)
		{
			for(int k=0;k<n;k++)
			{
				printf("%c",maps[j][k]);
			}
			printf("\n");
		}*/
		int k, x1, y1, x2, y2;
		scanf("%d%d%d%d%d", &k, &x1, &y1, &x2, &y2);
		if (maps[y1 - 1][x1 - 1] == '*' || maps[y2 - 1][x2 - 1] == '*')
			printf("no\n");
		else {
			bool flag = false;
			bool flag2 = false;
			for (int j = 0; j <= 3; j++) {
				//cout<<"fangxaing"<<endl;
				memset(visted, false, sizeof(visted));
				dfs(y1 - 1, x1 - 1, y2 - 1, x2 - 1, j, k, flag);
				if (flag)
					flag2 = true;
			}
			if (flag2)
				printf("yes\n");
			else
				printf("no\n");
		}


	}

}
